# Where to get API keys

## Brawl Stars

Website: https://developer.brawlstars.com/

Create a developer account, create an API key, and add it as:

```env
BRAWL_STARS_API_TOKEN="your-token"
```

## Clash Royale

Website: https://developer.clashroyale.com/

Create a developer account, create an API key, and add it as:

```env
CLASH_ROYALE_API_TOKEN="your-token"
```

If Cloudflare's outgoing IP causes an IP allowlist issue, you may need to use a proxy/static egress and set:

```env
CLASH_ROYALE_API_BASE="https://your-proxy.example.com/v1"
```

## Clash of Clans

Website: https://developer.clashofclans.com/

Create a developer account, create an API key, and add it as:

```env
CLASH_OF_CLANS_API_TOKEN="your-token"
```

If Cloudflare's outgoing IP causes an IP allowlist issue, point this to your proxy/static egress:

```env
CLASH_OF_CLANS_API_BASE="https://your-proxy.example.com/v1"
```

## PUBG

Website: https://developer.pubg.com/

Create an API key and add it as:

```env
PUBG_API_KEY="your-token"
PUBG_PLATFORM="steam"
```

PUBG platform shards commonly include `steam`, `kakao`, `psn`, `xbox`, and `console`. You can also set the shard per profile from the admin panel.
