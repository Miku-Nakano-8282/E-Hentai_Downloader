# Live Gaming Stats Tracker

A mobile-first gaming stats portfolio website built for Cloudflare Pages + Turso.

Supported games:

- Brawl Stars
- Clash Royale
- Clash of Clans
- PUBG

The public dashboard reads cached snapshots from Turso. The admin panel refreshes the real game APIs and saves every successful or failed refresh attempt into the database.

## Project structure

```txt
gaming-stats-tracker/
├─ functions/api/[[path]].ts      # Cloudflare Pages Functions API
├─ src/                           # React frontend
│  ├─ components/                  # UI components
│  ├─ lib/api.js                   # Frontend API client
│  ├─ utils/format.js              # Formatting helpers
│  ├─ App.jsx
│  └─ styles.css
├─ public/favicon.svg
├─ schema.sql                      # Same DB schema used by the function
├─ .dev.vars.example               # Local environment variable template
├─ wrangler.toml                   # Cloudflare config
├─ package.json
└─ vite.config.ts
```

## Required environment variables

Create these in Cloudflare as **secrets** when they contain private values.

```env
TURSO_DATABASE_URL="libsql://your-db-your-org.turso.io"
TURSO_AUTH_TOKEN="your-turso-auth-token"
ADMIN_KEY="change-this-long-random-admin-key"
```

Optional API tokens:

```env
BRAWL_STARS_API_TOKEN=""
CLASH_ROYALE_API_TOKEN=""
CLASH_OF_CLANS_API_TOKEN=""
PUBG_API_KEY=""
```

Optional API base overrides:

```env
BRAWL_STARS_API_BASE="https://api.brawlstars.com/v1"
CLASH_ROYALE_API_BASE="https://api.clashroyale.com/v1"
CLASH_OF_CLANS_API_BASE="https://api.clashofclans.com/v1"
PUBG_API_BASE="https://api.pubg.com"
PUBG_PLATFORM="steam"
```

> Important: Supercell developer keys are commonly IP-allowlisted. Cloudflare Pages/Workers usually do not give you a fixed outbound IP on normal plans. If a Supercell request returns `403 accessDenied`, use the API base override variables to point to your own small proxy/VPS with a static IP, or use an approved API proxy where available.

## Local setup

```bash
npm install
cp .dev.vars.example .dev.vars
```

Edit `.dev.vars` and put your Turso URL, Turso token, admin key, and any game API tokens you have.

Run locally:

```bash
npm run dev
```

Open the local URL shown by Wrangler. Then open the Admin panel, paste your `ADMIN_KEY`, click **Initialize DB**, add your profiles, and refresh them.

## Add profiles

Use the admin panel:

- Brawl Stars / Clash Royale / Clash of Clans: enter your player tag, with or without `#`.
- PUBG: enter the player name, then choose the platform shard like `steam`, `kakao`, `psn`, or `xbox`.

## Deploy to Cloudflare Pages from GitHub

1. Unzip this project.
2. Upload the folder to a GitHub repository.
3. Go to Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages** → connect your GitHub repo.
4. Build settings:
   - Framework preset: `Vite`
   - Build command: `npm run build`
   - Build output directory: `dist`
5. Add environment variables/secrets:
   - `TURSO_DATABASE_URL`
   - `TURSO_AUTH_TOKEN`
   - `ADMIN_KEY`
   - game API tokens you want to use
6. Deploy.
7. Open your deployed site and go to `/#admin`.
8. Paste your admin key, click **Initialize DB**, add profiles, then click **Refresh all**.

## Deploy with Wrangler CLI

```bash
npm install
cp .dev.vars.example .dev.vars
# edit .dev.vars first
npm run build
npx wrangler pages deploy dist --project-name gaming-stats-tracker
```

After deployment, set the production secrets in the Cloudflare dashboard and redeploy once.

## How the data flow works

```txt
Visitor browser -> /api/dashboard -> Turso cached snapshots -> fast UI
Admin browser -> /api/admin/refresh -> Game APIs -> Turso snapshots -> dashboard
```

This prevents visitors from burning your API limits and keeps all API keys server-side.

## Game API notes

- Brawl Stars: player profile and battlelog are fetched.
- Clash Royale: player profile and battlelog are fetched.
- Clash of Clans: player profile is fetched. The official player endpoint does not behave like a match-history API, so the UI shows achievements/highlights instead of recent battles.
- PUBG: player lookup and lifetime stats are fetched. Recent match IDs are shown without fetching every match detail, keeping the app inside PUBG's small free rate limit.

## Admin panel security

The admin panel uses a simple `ADMIN_KEY` header. Make the key long and random. Do not share it. For a personal portfolio/project this is enough; for a public multi-user product, replace it with real authentication.

## Useful commands

```bash
npm run dev       # local Cloudflare Pages dev server
npm run build     # production frontend build
npm run deploy    # build + deploy with Wrangler
npm run typecheck # TypeScript check
```
