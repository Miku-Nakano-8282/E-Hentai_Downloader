export default function Footer() {
  return (
    <footer className="footer">
      <p>Built for fast public reads: visitors see cached snapshots, while the admin panel refreshes the external game APIs.</p>
    </footer>
  );
}
