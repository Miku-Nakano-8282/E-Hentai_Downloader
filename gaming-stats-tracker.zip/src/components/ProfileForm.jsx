import { useMemo, useState } from "react";
import { GAME_CONFIG, PUBG_PLATFORMS } from "../constants.js";

const emptyProfile = {
  game: "brawl_stars",
  displayName: "",
  playerTag: "",
  platform: "steam",
  region: "",
  avatarUrl: "",
  isFeatured: true,
  sortOrder: 0
};

export default function ProfileForm({ editing, onCancel, onSave, busy }) {
  const [form, setForm] = useState(() => editing ? {
    game: editing.game,
    displayName: editing.display_name || editing.displayName || "",
    playerTag: editing.player_tag || editing.playerTag || "",
    platform: editing.platform || "steam",
    region: editing.region || "",
    avatarUrl: editing.avatar_url || editing.avatarUrl || "",
    isFeatured: Boolean(editing.is_featured ?? editing.isFeatured ?? true),
    sortOrder: Number(editing.sort_order ?? editing.sortOrder ?? 0)
  } : emptyProfile);

  const config = useMemo(() => GAME_CONFIG[form.game] || GAME_CONFIG.brawl_stars, [form.game]);

  function update(key, value) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event) {
    event.preventDefault();
    onSave(form);
    if (!editing) setForm(emptyProfile);
  }

  return (
    <form className="admin-form" onSubmit={submit}>
      <div className="form-grid">
        <label>
          <span>Game</span>
          <select value={form.game} onChange={(event) => update("game", event.target.value)}>
            {Object.entries(GAME_CONFIG).map(([key, value]) => (
              <option key={key} value={key}>{value.label}</option>
            ))}
          </select>
        </label>

        <label>
          <span>Display name</span>
          <input value={form.displayName} onChange={(event) => update("displayName", event.target.value)} placeholder="Siam Gaming" required />
        </label>

        <label>
          <span>{config.tagLabel}</span>
          <input value={form.playerTag} onChange={(event) => update("playerTag", event.target.value)} placeholder={config.tagPlaceholder} required />
        </label>

        {form.game === "pubg" ? (
          <label>
            <span>PUBG platform shard</span>
            <select value={form.platform} onChange={(event) => update("platform", event.target.value)}>
              {PUBG_PLATFORMS.map((platform) => <option key={platform} value={platform}>{platform}</option>)}
            </select>
          </label>
        ) : (
          <label>
            <span>Platform / note</span>
            <input value={form.platform} onChange={(event) => update("platform", event.target.value)} placeholder="Optional" />
          </label>
        )}

        <label>
          <span>Region</span>
          <input value={form.region} onChange={(event) => update("region", event.target.value)} placeholder="BD / Asia / Optional" />
        </label>

        <label>
          <span>Avatar URL</span>
          <input value={form.avatarUrl} onChange={(event) => update("avatarUrl", event.target.value)} placeholder="https://... optional" />
        </label>

        <label>
          <span>Sort order</span>
          <input type="number" value={form.sortOrder} onChange={(event) => update("sortOrder", Number(event.target.value))} />
        </label>

        <label className="checkbox-line">
          <input type="checkbox" checked={form.isFeatured} onChange={(event) => update("isFeatured", event.target.checked)} />
          <span>Show on public dashboard</span>
        </label>
      </div>

      <div className="form-actions">
        {editing ? <button className="ghost-button" type="button" onClick={onCancel}>Cancel</button> : null}
        <button className="solid-button" type="submit" disabled={busy}>{editing ? "Save changes" : "Add profile"}</button>
      </div>
    </form>
  );
}
