import { GAME_CONFIG } from "../constants.js";
import { formatNumber, timeAgo, safeText } from "../utils/format.js";
import MiniChart from "./MiniChart.jsx";
import StatCard from "./StatCard.jsx";

export default function GameSection({ profile }) {
  const config = GAME_CONFIG[profile.game] || GAME_CONFIG.brawl_stars;
  const latest = profile.latest?.summary;
  const lastAttempt = profile.lastAttempt;
  const status = profile.latest?.status || lastAttempt?.status || "pending";
  const metrics = latest?.metrics || [];
  const recent = latest?.recent || [];
  const highlights = latest?.highlights || [];
  const title = latest?.title || profile.display_name;
  const subtitle = latest?.subtitle || `${config.label} profile ${profile.player_tag}`;

  return (
    <section className={`game-panel game-panel--${config.accent}`}>
      <div className="game-panel__header">
        <div className="game-title">
          <span className="game-title__icon">{config.icon}</span>
          <div>
            <span>{config.label}</span>
            <h2>{safeText(title)}</h2>
          </div>
        </div>
        <div className={`status-pill status-pill--${status}`}>
          {status === "success" ? "Live cache" : status === "error" ? "Needs refresh" : "Waiting"}
        </div>
      </div>

      <p className="game-subtitle">{subtitle}</p>

      <div className="primary-row">
        <article className="primary-stat">
          <span>{latest?.primaryMetric?.label || "Primary stat"}</span>
          <strong>{formatNumber(latest?.primaryMetric?.value ?? "—")}</strong>
          <small>Updated {timeAgo(profile.latest?.fetchedAt)}</small>
        </article>
        <MiniChart points={profile.history || []} label={`${latest?.primaryMetric?.label || "Stats"} trend`} />
      </div>

      <div className="metric-grid">
        {metrics.slice(0, 8).map((metric) => (
          <StatCard key={`${metric.label}-${metric.value}`} label={metric.label} value={metric.value} help={metric.help} />
        ))}
      </div>

      <div className="panel-grid">
        <div className="panel-box">
          <div className="box-heading">
            <h3>Recent activity</h3>
            <span>{recent.length ? `${recent.length} items` : "No data"}</span>
          </div>
          <div className="activity-list">
            {recent.length ? recent.slice(0, 5).map((item, index) => (
              <div className="activity-item" key={`${item.title}-${index}`}>
                <div>
                  <strong>{safeText(item.title)}</strong>
                  <p>{safeText(item.subtitle, "Latest API item")}</p>
                </div>
                <span className={`result result--${String(item.result || "neutral").toLowerCase()}`}>{safeText(item.value || item.result, "—")}</span>
              </div>
            )) : <p className="muted">This API did not return recent matches for this profile yet.</p>}
          </div>
        </div>

        <div className="panel-box">
          <div className="box-heading">
            <h3>Highlights</h3>
            <span>{profile.player_tag}</span>
          </div>
          <div className="highlight-list">
            {highlights.length ? highlights.slice(0, 6).map((item, index) => (
              <span key={`${item}-${index}`}>{item}</span>
            )) : <p className="muted">Refresh this profile to generate highlights.</p>}
          </div>
          {lastAttempt?.status === "error" ? <p className="error-note">Last refresh failed: {lastAttempt.error}</p> : null}
        </div>
      </div>
    </section>
  );
}
