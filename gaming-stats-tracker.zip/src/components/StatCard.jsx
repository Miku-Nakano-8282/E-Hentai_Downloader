import { formatNumber } from "../utils/format.js";

export default function StatCard({ label, value, help }) {
  return (
    <article className="stat-card">
      <span>{label}</span>
      <strong>{formatNumber(value)}</strong>
      {help ? <small>{help}</small> : null}
    </article>
  );
}
