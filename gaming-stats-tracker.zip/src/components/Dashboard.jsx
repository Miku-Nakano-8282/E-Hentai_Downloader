import EmptyState from "./EmptyState.jsx";
import GameSection from "./GameSection.jsx";

export default function Dashboard({ profiles = [], onAdmin }) {
  if (!profiles.length) return <EmptyState onAdmin={onAdmin} />;

  return (
    <main className="dashboard">
      {profiles.map((profile) => (
        <GameSection key={profile.id} profile={profile} />
      ))}
    </main>
  );
}
