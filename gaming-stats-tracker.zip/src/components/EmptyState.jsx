export default function EmptyState({ onAdmin }) {
  return (
    <section className="empty-state">
      <div>
        <span className="empty-state__icon">🎮</span>
        <h2>No gaming profiles yet</h2>
        <p>Add your Brawl Stars, Clash Royale, Clash of Clans, or PUBG profile from the admin panel. After the first refresh, the public dashboard will show cached live stats from Turso.</p>
      </div>
      <button className="solid-button" onClick={onAdmin}>Open Admin Panel</button>
    </section>
  );
}
