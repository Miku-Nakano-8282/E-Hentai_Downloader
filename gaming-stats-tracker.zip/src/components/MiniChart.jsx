import { formatNumber } from "../utils/format.js";

export default function MiniChart({ points = [], label = "Trend" }) {
  const clean = points
    .map((point) => ({ ...point, value: Number(point.value) }))
    .filter((point) => Number.isFinite(point.value));

  if (clean.length < 2) {
    return (
      <div className="mini-chart mini-chart--empty">
        <span>{label}</span>
        <strong>Need 2 snapshots</strong>
      </div>
    );
  }

  const width = 320;
  const height = 96;
  const padding = 10;
  const values = clean.map((point) => point.value);
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  const coords = clean.map((point, index) => {
    const x = padding + (index / Math.max(clean.length - 1, 1)) * (width - padding * 2);
    const y = height - padding - ((point.value - min) / range) * (height - padding * 2);
    return { x, y, point };
  });

  const polyline = coords.map(({ x, y }) => `${x},${y}`).join(" ");
  const last = clean[clean.length - 1];

  return (
    <div className="mini-chart" aria-label={`${label} chart`}>
      <div className="mini-chart__top">
        <span>{label}</span>
        <strong>{formatNumber(last.value)}</strong>
      </div>
      <svg viewBox={`0 0 ${width} ${height}`} role="img" aria-hidden="true">
        <path className="chart-grid" d={`M ${padding} ${height - padding} H ${width - padding}`} />
        <polyline className="chart-line" points={polyline} fill="none" />
        {coords.map(({ x, y }, index) => (
          <circle className="chart-dot" key={index} cx={x} cy={y} r={index === coords.length - 1 ? 4 : 2.6} />
        ))}
      </svg>
    </div>
  );
}
