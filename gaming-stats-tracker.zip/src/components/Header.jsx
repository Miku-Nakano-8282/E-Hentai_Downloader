import { DEFAULT_SETTINGS } from "../constants.js";

export default function Header({ settings = {}, profileCount = 0, onRefresh, isRefreshing, onAdmin }) {
  const title = settings.site_title || DEFAULT_SETTINGS.site_title;
  const subtitle = settings.site_subtitle || DEFAULT_SETTINGS.site_subtitle;
  const badge = settings.hero_badge || DEFAULT_SETTINGS.hero_badge;

  return (
    <header className="hero">
      <div className="hero__glow" aria-hidden="true" />
      <nav className="topbar">
        <div className="brand">
          <span className="brand__logo">GG</span>
          <span>{settings.profile_owner || DEFAULT_SETTINGS.profile_owner}</span>
        </div>
        <div className="topbar__actions">
          <button className="ghost-button" onClick={onRefresh} disabled={isRefreshing}>
            {isRefreshing ? "Refreshing..." : "Refresh"}
          </button>
          <button className="solid-button" onClick={onAdmin}>Admin</button>
        </div>
      </nav>

      <div className="hero__content">
        <span className="eyebrow">{badge}</span>
        <h1>{title}</h1>
        <p>{subtitle}</p>
        <div className="hero__meta">
          <span>{profileCount} tracked profile{profileCount === 1 ? "" : "s"}</span>
          <span>Cached API snapshots</span>
          <span>Mobile-first UI</span>
        </div>
      </div>
    </header>
  );
}
