import { useEffect, useMemo, useState } from "react";
import { api } from "../lib/api.js";
import { GAME_CONFIG, DEFAULT_SETTINGS } from "../constants.js";
import { timeAgo } from "../utils/format.js";
import ProfileForm from "./ProfileForm.jsx";

export default function AdminPanel({ open, onClose, onChanged, settings = {} }) {
  const [adminKey, setAdminKey] = useState(() => localStorage.getItem("gst_admin_key") || "");
  const [profiles, setProfiles] = useState([]);
  const [editing, setEditing] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [settingsForm, setSettingsForm] = useState(() => ({ ...DEFAULT_SETTINGS, ...settings }));

  const canUse = useMemo(() => adminKey.trim().length > 0, [adminKey]);

  useEffect(() => {
    setSettingsForm({ ...DEFAULT_SETTINGS, ...settings });
  }, [settings]);

  useEffect(() => {
    if (!open || !canUse) return;
    loadProfiles().catch((error) => setMessage(error.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  function saveKey(value) {
    setAdminKey(value);
    localStorage.setItem("gst_admin_key", value);
  }

  async function run(label, fn) {
    setBusy(true);
    setMessage(label);
    try {
      const result = await fn();
      setMessage(result?.message || "Done");
      return result;
    } catch (error) {
      setMessage(error.message || "Something went wrong");
      throw error;
    } finally {
      setBusy(false);
    }
  }

  async function loadProfiles() {
    const result = await run("Loading profiles...", () => api.adminProfiles(adminKey));
    setProfiles(result.profiles || []);
  }

  async function initializeDatabase() {
    await run("Initializing database...", () => api.adminInit(adminKey));
    await loadProfiles();
    onChanged?.();
  }

  async function saveProfile(form) {
    if (editing) {
      await run("Saving profile...", () => api.updateProfile(adminKey, editing.id, form));
      setEditing(null);
    } else {
      await run("Creating profile...", () => api.createProfile(adminKey, form));
    }
    await loadProfiles();
    onChanged?.();
  }

  async function deleteProfile(profile) {
    const confirmed = window.confirm(`Delete ${profile.display_name || profile.displayName}? This also deletes its saved snapshots.`);
    if (!confirmed) return;
    await run("Deleting profile...", () => api.deleteProfile(adminKey, profile.id));
    await loadProfiles();
    onChanged?.();
  }

  async function refreshProfile(profile) {
    try {
      await run(`Refreshing ${profile.display_name}...`, () => api.refreshProfile(adminKey, profile.id));
    } catch {
      // Error message is already shown and saved by the API.
    }
    await loadProfiles();
    onChanged?.();
  }

  async function refreshAll() {
    try {
      const result = await run("Refreshing all profiles...", () => api.refreshAll(adminKey));
      const failed = (result.results || []).filter((item) => item.status === "error").length;
      setMessage(failed ? `Finished with ${failed} failed refresh(es).` : "All profiles refreshed.");
    } catch {
      // Keep message from run().
    }
    await loadProfiles();
    onChanged?.();
  }

  async function saveSettings(event) {
    event.preventDefault();
    await run("Saving settings...", () => api.updateSettings(adminKey, settingsForm));
    onChanged?.();
  }

  if (!open) return null;

  return (
    <div className="admin-shell" role="dialog" aria-modal="true" aria-label="Admin panel">
      <div className="admin-backdrop" onClick={onClose} />
      <section className="admin-panel">
        <div className="admin-panel__header">
          <div>
            <span className="eyebrow">Protected controls</span>
            <h2>Admin Panel</h2>
          </div>
          <button className="ghost-button" onClick={onClose}>Close</button>
        </div>

        <div className="admin-card">
          <label>
            <span>Admin key</span>
            <input
              type="password"
              value={adminKey}
              onChange={(event) => saveKey(event.target.value)}
              placeholder="Paste ADMIN_KEY from Cloudflare variables"
            />
          </label>
          <div className="admin-actions">
            <button className="ghost-button" onClick={initializeDatabase} disabled={!canUse || busy}>Initialize DB</button>
            <button className="ghost-button" onClick={loadProfiles} disabled={!canUse || busy}>Load profiles</button>
            <button className="solid-button" onClick={refreshAll} disabled={!canUse || busy || !profiles.length}>Refresh all</button>
          </div>
          {message ? <p className="admin-message">{message}</p> : null}
        </div>

        <div className="admin-card">
          <div className="box-heading">
            <h3>{editing ? "Edit profile" : "Add tracked profile"}</h3>
            <span>{Object.keys(GAME_CONFIG).length} games supported</span>
          </div>
          <ProfileForm editing={editing} onCancel={() => setEditing(null)} onSave={saveProfile} busy={busy || !canUse} />
        </div>

        <form className="admin-card" onSubmit={saveSettings}>
          <div className="box-heading">
            <h3>Homepage text</h3>
            <span>Saved in Turso</span>
          </div>
          <div className="form-grid">
            <label>
              <span>Owner / brand</span>
              <input value={settingsForm.profile_owner || ""} onChange={(e) => setSettingsForm({ ...settingsForm, profile_owner: e.target.value })} />
            </label>
            <label>
              <span>Site title</span>
              <input value={settingsForm.site_title || ""} onChange={(e) => setSettingsForm({ ...settingsForm, site_title: e.target.value })} />
            </label>
            <label>
              <span>Subtitle</span>
              <input value={settingsForm.site_subtitle || ""} onChange={(e) => setSettingsForm({ ...settingsForm, site_subtitle: e.target.value })} />
            </label>
            <label>
              <span>Badge</span>
              <input value={settingsForm.hero_badge || ""} onChange={(e) => setSettingsForm({ ...settingsForm, hero_badge: e.target.value })} />
            </label>
          </div>
          <div className="form-actions">
            <button className="solid-button" disabled={!canUse || busy}>Save homepage</button>
          </div>
        </form>

        <div className="admin-card">
          <div className="box-heading">
            <h3>Profiles</h3>
            <span>{profiles.length} saved</span>
          </div>
          <div className="admin-profile-list">
            {profiles.map((profile) => {
              const config = GAME_CONFIG[profile.game] || GAME_CONFIG.brawl_stars;
              return (
                <article key={profile.id} className="admin-profile-item">
                  <div>
                    <strong>{config.icon} {profile.display_name}</strong>
                    <p>{config.label} · {profile.player_tag} {profile.platform ? `· ${profile.platform}` : ""}</p>
                    <small>Updated {timeAgo(profile.updated_at)}</small>
                  </div>
                  <div className="admin-profile-actions">
                    <button className="ghost-button" onClick={() => refreshProfile(profile)} disabled={busy}>Refresh</button>
                    <button className="ghost-button" onClick={() => setEditing(profile)} disabled={busy}>Edit</button>
                    <button className="danger-button" onClick={() => deleteProfile(profile)} disabled={busy}>Delete</button>
                  </div>
                </article>
              );
            })}
            {!profiles.length ? <p className="muted">No profiles loaded. Add one above or click Load profiles.</p> : null}
          </div>
        </div>
      </section>
    </div>
  );
}
