export const GAME_CONFIG = {
  brawl_stars: {
    label: "Brawl Stars",
    short: "Brawl",
    icon: "⭐",
    accent: "purple",
    tagLabel: "Player Tag",
    tagPlaceholder: "#2PP or 2PP..."
  },
  clash_royale: {
    label: "Clash Royale",
    short: "Royale",
    icon: "👑",
    accent: "blue",
    tagLabel: "Player Tag",
    tagPlaceholder: "#2PP or 2PP..."
  },
  clash_of_clans: {
    label: "Clash of Clans",
    short: "CoC",
    icon: "🛡️",
    accent: "orange",
    tagLabel: "Player Tag",
    tagPlaceholder: "#2PP or 2PP..."
  },
  pubg: {
    label: "PUBG",
    short: "PUBG",
    icon: "🎯",
    accent: "green",
    tagLabel: "Player Name",
    tagPlaceholder: "PUBG player name"
  }
};

export const PUBG_PLATFORMS = [
  "steam",
  "kakao",
  "psn",
  "xbox",
  "console",
  "stadia"
];

export const DEFAULT_SETTINGS = {
  site_title: "Live Gaming Stats",
  site_subtitle: "Real-time trophies, wins, matches, and progression from your favorite games.",
  hero_badge: "Cloudflare + Turso powered",
  profile_owner: "Your Gaming Profile"
};
