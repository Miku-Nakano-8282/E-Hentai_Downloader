import { useCallback, useEffect, useState } from "react";
import { api } from "./lib/api.js";
import Header from "./components/Header.jsx";
import Dashboard from "./components/Dashboard.jsx";
import AdminPanel from "./components/AdminPanel.jsx";
import Footer from "./components/Footer.jsx";

export default function App() {
  const [data, setData] = useState({ settings: {}, profiles: [] });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [adminOpen, setAdminOpen] = useState(() => window.location.hash === "#admin");

  const loadDashboard = useCallback(async (silent = false) => {
    if (silent) setRefreshing(true);
    else setLoading(true);
    setError("");
    try {
      const result = await api.dashboard();
      setData({ settings: result.settings || {}, profiles: result.profiles || [] });
    } catch (err) {
      setError(err.message || "Dashboard failed to load");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
    const timer = window.setInterval(() => loadDashboard(true), 60000);
    return () => window.clearInterval(timer);
  }, [loadDashboard]);

  function openAdmin() {
    setAdminOpen(true);
    window.history.replaceState(null, "", "#admin");
  }

  function closeAdmin() {
    setAdminOpen(false);
    if (window.location.hash === "#admin") {
      window.history.replaceState(null, "", window.location.pathname);
    }
  }

  return (
    <div className="app-shell">
      <Header
        settings={data.settings}
        profileCount={data.profiles.length}
        onRefresh={() => loadDashboard(true)}
        isRefreshing={refreshing}
        onAdmin={openAdmin}
      />

      {error ? (
        <section className="global-error">
          <strong>Dashboard error</strong>
          <p>{error}</p>
          <button className="solid-button" onClick={() => loadDashboard()}>Try again</button>
        </section>
      ) : null}

      {loading ? <LoadingDashboard /> : <Dashboard profiles={data.profiles} onAdmin={openAdmin} />}
      <Footer />

      <AdminPanel
        open={adminOpen}
        onClose={closeAdmin}
        settings={data.settings}
        onChanged={() => loadDashboard(true)}
      />
    </div>
  );
}

function LoadingDashboard() {
  return (
    <main className="dashboard">
      {[0, 1].map((item) => (
        <section className="game-panel skeleton" key={item}>
          <div className="skeleton-line skeleton-line--wide" />
          <div className="skeleton-grid">
            <div className="skeleton-box" />
            <div className="skeleton-box" />
            <div className="skeleton-box" />
          </div>
        </section>
      ))}
    </main>
  );
}
