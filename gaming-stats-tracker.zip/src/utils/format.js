export function formatNumber(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return value ?? "—";
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: number % 1 ? 2 : 0 }).format(number);
}

export function formatPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) return "—";
  return `${number.toFixed(number % 1 ? 1 : 0)}%`;
}

export function timeAgo(input) {
  if (!input) return "Never";
  const time = new Date(input).getTime();
  if (!Number.isFinite(time)) return "Unknown";
  const diff = Date.now() - time;
  const minutes = Math.round(diff / 60000);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.round(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(input).toLocaleDateString();
}

export function safeText(value, fallback = "—") {
  return String(value ?? "").trim() || fallback;
}
