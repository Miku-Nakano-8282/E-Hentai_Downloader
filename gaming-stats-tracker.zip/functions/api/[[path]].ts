import { createClient, type Client } from "@libsql/client/web";

interface Env {
  TURSO_DATABASE_URL: string;
  TURSO_AUTH_TOKEN: string;
  ADMIN_KEY: string;
  BRAWL_STARS_API_TOKEN?: string;
  CLASH_ROYALE_API_TOKEN?: string;
  CLASH_OF_CLANS_API_TOKEN?: string;
  PUBG_API_KEY?: string;
  BRAWL_STARS_API_BASE?: string;
  CLASH_ROYALE_API_BASE?: string;
  CLASH_OF_CLANS_API_BASE?: string;
  PUBG_API_BASE?: string;
  PUBG_PLATFORM?: string;
}

type GameKey = "brawl_stars" | "clash_royale" | "clash_of_clans" | "pubg";

type Profile = {
  id: string;
  game: GameKey;
  display_name: string;
  player_tag: string;
  platform: string;
  region: string;
  avatar_url: string;
  is_featured: number;
  sort_order: number;
  created_at?: string;
  updated_at?: string;
};

type SummaryMetric = { label: string; value: string | number; help?: string };
type Summary = {
  game: GameKey;
  title: string;
  subtitle: string;
  primaryMetric: SummaryMetric;
  metrics: SummaryMetric[];
  recent: Array<{ title: string; subtitle?: string; result?: string; value?: string | number }>;
  highlights: string[];
  updatedAt: string;
};

const GAME_KEYS = new Set<GameKey>(["brawl_stars", "clash_royale", "clash_of_clans", "pubg"]);
const MAX_HISTORY_PER_PROFILE = 30;
let schemaReady = false;
let cachedDb: Client | null = null;
let cachedDbKey = "";

function json(data: unknown, init: ResponseInit = {}) {
  return new Response(JSON.stringify(data, null, 2), {
    ...init,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...(init.headers || {})
    }
  });
}

function ok(data: Record<string, unknown> = {}) {
  return json({ ok: true, ...data });
}

function normalizeError(error: unknown) {
  if (error instanceof Error) return error.message;
  return String(error || "Unknown error");
}

function requireEnv(env: Env) {
  if (!env.TURSO_DATABASE_URL || !env.TURSO_AUTH_TOKEN) {
    throw new Error("Missing TURSO_DATABASE_URL or TURSO_AUTH_TOKEN. Add them in Cloudflare variables/secrets.");
  }
}

function getDb(env: Env) {
  requireEnv(env);
  const cacheKey = `${env.TURSO_DATABASE_URL}:${env.TURSO_AUTH_TOKEN.slice(-12)}`;
  if (!cachedDb || cachedDbKey !== cacheKey) {
    cachedDb = createClient({
      url: env.TURSO_DATABASE_URL,
      authToken: env.TURSO_AUTH_TOKEN
    });
    cachedDbKey = cacheKey;
  }
  return cachedDb;
}

async function ensureSchema(db: Client) {
  if (schemaReady) return;
  const statements = [
    `CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `CREATE TABLE IF NOT EXISTS profiles (
      id TEXT PRIMARY KEY,
      game TEXT NOT NULL,
      display_name TEXT NOT NULL,
      player_tag TEXT NOT NULL,
      platform TEXT NOT NULL DEFAULT '',
      region TEXT NOT NULL DEFAULT '',
      avatar_url TEXT NOT NULL DEFAULT '',
      is_featured INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `CREATE UNIQUE INDEX IF NOT EXISTS idx_profiles_game_tag ON profiles(game, player_tag)`,
    `CREATE INDEX IF NOT EXISTS idx_profiles_sort ON profiles(sort_order, created_at)`,
    `CREATE TABLE IF NOT EXISTS snapshots (
      id TEXT PRIMARY KEY,
      profile_id TEXT NOT NULL,
      game TEXT NOT NULL,
      fetched_at TEXT NOT NULL DEFAULT (datetime('now')),
      source TEXT NOT NULL DEFAULT 'api',
      status TEXT NOT NULL,
      summary_json TEXT NOT NULL,
      raw_json TEXT,
      error TEXT,
      FOREIGN KEY (profile_id) REFERENCES profiles(id) ON DELETE CASCADE
    )`,
    `CREATE INDEX IF NOT EXISTS idx_snapshots_profile_time ON snapshots(profile_id, fetched_at DESC)`,
    `CREATE INDEX IF NOT EXISTS idx_snapshots_game_time ON snapshots(game, fetched_at DESC)`,
    `CREATE TABLE IF NOT EXISTS activity_log (
      id TEXT PRIMARY KEY,
      action TEXT NOT NULL,
      detail TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )`,
    `CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_log(created_at DESC)`
  ];

  for (const sql of statements) {
    await db.execute(sql);
  }

  const defaultSettings: Record<string, string> = {
    site_title: "Live Gaming Stats",
    site_subtitle: "Real-time trophies, wins, matches, and progression from your favorite games.",
    hero_badge: "Cloudflare + Turso powered",
    profile_owner: "Your Gaming Profile"
  };

  for (const [key, value] of Object.entries(defaultSettings)) {
    await db.execute({
      sql: `INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)`,
      args: [key, value]
    });
  }

  schemaReady = true;
}

function assertAdmin(request: Request, env: Env) {
  const incoming = request.headers.get("x-admin-key") || "";
  if (!env.ADMIN_KEY || env.ADMIN_KEY.length < 12) {
    return "ADMIN_KEY is not configured or is too short. Set a long random key in Cloudflare secrets.";
  }
  if (incoming !== env.ADMIN_KEY) return "Unauthorized admin key.";
  return null;
}

async function readJson(request: Request) {
  const text = await request.text();
  if (!text) return {};
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("Invalid JSON body.");
  }
}

function parsePath(request: Request) {
  const pathname = new URL(request.url).pathname;
  return pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
}

function sanitizeText(value: unknown, max = 220) {
  return String(value ?? "").trim().slice(0, max);
}

function normalizeSupercellTag(tag: string) {
  const clean = tag.trim().toUpperCase().replace(/\s+/g, "");
  if (!clean) return "";
  return clean.startsWith("#") ? clean : `#${clean}`;
}

function normalizeProfileInput(body: any, existing?: Profile) {
  const game = sanitizeText(body.game || existing?.game) as GameKey;
  if (!GAME_KEYS.has(game)) throw new Error("Unsupported game selected.");

  const displayName = sanitizeText(body.displayName ?? body.display_name ?? existing?.display_name, 80);
  if (!displayName) throw new Error("Display name is required.");

  let playerTag = sanitizeText(body.playerTag ?? body.player_tag ?? existing?.player_tag, 90);
  if (game !== "pubg") playerTag = normalizeSupercellTag(playerTag);
  if (!playerTag) throw new Error(game === "pubg" ? "PUBG player name is required." : "Player tag is required.");

  return {
    game,
    display_name: displayName,
    player_tag: playerTag,
    platform: sanitizeText(body.platform ?? existing?.platform ?? (game === "pubg" ? "steam" : ""), 40),
    region: sanitizeText(body.region ?? existing?.region ?? "", 40),
    avatar_url: sanitizeText(body.avatarUrl ?? body.avatar_url ?? existing?.avatar_url ?? "", 400),
    is_featured: body.isFeatured ?? body.is_featured ?? existing?.is_featured ?? true ? 1 : 0,
    sort_order: Number(body.sortOrder ?? body.sort_order ?? existing?.sort_order ?? 0) || 0
  };
}

function encodeTag(tag: string) {
  return encodeURIComponent(tag.startsWith("#") ? tag : `#${tag}`);
}

function number(value: unknown, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function percent(numerator: number, denominator: number) {
  if (!denominator) return 0;
  return Math.round((numerator / denominator) * 1000) / 10;
}

function safeJsonParse(value: unknown) {
  if (typeof value !== "string") return null;
  try { return JSON.parse(value); } catch { return null; }
}

async function logActivity(db: Client, action: string, detail?: unknown) {
  await db.execute({
    sql: `INSERT INTO activity_log (id, action, detail) VALUES (?, ?, ?)`,
    args: [crypto.randomUUID(), action, detail === undefined ? null : JSON.stringify(detail)]
  });
}

async function getSettings(db: Client) {
  const result = await db.execute(`SELECT key, value FROM settings`);
  const settings: Record<string, string> = {};
  for (const row of result.rows as any[]) settings[row.key] = row.value;
  return settings;
}

async function getProfiles(db: Client, featuredOnly = false) {
  const sql = featuredOnly
    ? `SELECT * FROM profiles WHERE is_featured = 1 ORDER BY sort_order ASC, created_at ASC`
    : `SELECT * FROM profiles ORDER BY sort_order ASC, created_at ASC`;
  const result = await db.execute(sql);
  return result.rows as unknown as Profile[];
}

async function getProfile(db: Client, id: string) {
  const result = await db.execute({ sql: `SELECT * FROM profiles WHERE id = ?`, args: [id] });
  return (result.rows[0] as unknown as Profile | undefined) || null;
}

async function getSnapshots(db: Client, profiles: Profile[]) {
  if (!profiles.length) return new Map<string, any[]>();
  const placeholders = profiles.map(() => "?").join(",");
  const result = await db.execute({
    sql: `SELECT * FROM snapshots WHERE profile_id IN (${placeholders}) ORDER BY fetched_at DESC LIMIT ?`,
    args: [...profiles.map((profile) => profile.id), profiles.length * MAX_HISTORY_PER_PROFILE * 2]
  });

  const map = new Map<string, any[]>();
  for (const row of result.rows as any[]) {
    const id = String(row.profile_id);
    if (!map.has(id)) map.set(id, []);
    map.get(id)!.push(row);
  }
  return map;
}

function buildPublicProfile(profile: Profile, snapshots: any[]) {
  const parsed = snapshots.map((row) => ({
    id: row.id,
    status: row.status,
    source: row.source,
    fetchedAt: row.fetched_at,
    error: row.error,
    summary: safeJsonParse(row.summary_json)
  }));

  const latestSuccess = parsed.find((row) => row.status === "success" || row.status === "manual") || null;
  const lastAttempt = parsed[0] || null;
  const history = parsed
    .filter((row) => (row.status === "success" || row.status === "manual") && Number.isFinite(Number(row.summary?.primaryMetric?.value)))
    .slice(0, MAX_HISTORY_PER_PROFILE)
    .reverse()
    .map((row) => ({
      label: new Date(row.fetchedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" }),
      value: Number(row.summary.primaryMetric.value),
      fetchedAt: row.fetchedAt
    }));

  return {
    ...profile,
    latest: latestSuccess,
    lastAttempt,
    history
  };
}

async function fetchJson(url: string, headers: HeadersInit) {
  const response = await fetch(url, { headers });
  const text = await response.text();
  let data: any = null;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }

  if (!response.ok) {
    const message = data?.message || data?.reason || data?.errors?.[0]?.detail || data?.title || text.slice(0, 200);
    throw new Error(`${response.status} ${response.statusText}: ${message || "API request failed"}`);
  }
  return data;
}

async function fetchSupercell(path: string, token: string | undefined, base: string | undefined, fallbackBase: string) {
  if (!token) throw new Error(`Missing API token for ${fallbackBase}. Add the token in Cloudflare secrets.`);
  const root = (base || fallbackBase).replace(/\/$/, "");
  return fetchJson(`${root}${path}`, {
    authorization: `Bearer ${token}`,
    accept: "application/json"
  });
}

function topBrawlBrawler(player: any) {
  const brawlers = Array.isArray(player?.brawlers) ? player.brawlers : [];
  return brawlers.sort((a: any, b: any) => number(b.trophies) - number(a.trophies))[0];
}

function recentBrawlItems(battleLog: any) {
  const items = Array.isArray(battleLog?.items) ? battleLog.items : [];
  return items.slice(0, 5).map((item: any) => ({
    title: item.event?.mode || item.battle?.mode || item.battle?.type || "Recent match",
    subtitle: item.event?.map ? `${item.event.map} · ${new Date(item.battleTime).toLocaleDateString()}` : item.battleTime,
    result: item.battle?.result || "neutral",
    value: item.battle?.trophyChange ? `${item.battle.trophyChange > 0 ? "+" : ""}${item.battle.trophyChange}` : item.battle?.result
  }));
}

async function fetchBrawlStars(env: Env, profile: Profile): Promise<{ summary: Summary; raw: unknown }> {
  const player = await fetchSupercell(`/players/${encodeTag(profile.player_tag)}`, env.BRAWL_STARS_API_TOKEN, env.BRAWL_STARS_API_BASE, "https://api.brawlstars.com/v1");
  let battleLog: any = { items: [] };
  try {
    battleLog = await fetchSupercell(`/players/${encodeTag(profile.player_tag)}/battlelog`, env.BRAWL_STARS_API_TOKEN, env.BRAWL_STARS_API_BASE, "https://api.brawlstars.com/v1");
  } catch (error) {
    battleLog = { items: [], warning: normalizeError(error) };
  }

  const brawler = topBrawlBrawler(player);
  const recent = recentBrawlItems(battleLog);
  const wins = recent.filter((item: any) => String(item.result).toLowerCase() === "victory").length;
  const known = recent.filter((item: any) => ["victory", "defeat", "draw"].includes(String(item.result).toLowerCase())).length;

  return {
    summary: {
      game: "brawl_stars",
      title: player.name || profile.display_name,
      subtitle: `${player.tag || profile.player_tag} · Level ${player.expLevel || "—"}`,
      primaryMetric: { label: "Trophies", value: number(player.trophies) },
      metrics: [
        { label: "Highest trophies", value: number(player.highestTrophies) },
        { label: "3v3 wins", value: number(player["3vs3Victories"]) },
        { label: "Solo wins", value: number(player.soloVictories) },
        { label: "Duo wins", value: number(player.duoVictories) },
        { label: "Brawlers", value: Array.isArray(player.brawlers) ? player.brawlers.length : 0 },
        { label: "Recent win rate", value: percent(wins, known), help: known ? "Last battlelog items" : "No recent results" }
      ],
      recent,
      highlights: [
        brawler ? `Top brawler: ${brawler.name} (${brawler.trophies} trophies)` : "No brawler list found",
        player.club?.name ? `Club: ${player.club.name}` : "No club shown",
        `Experience level: ${player.expLevel || "—"}`
      ],
      updatedAt: new Date().toISOString()
    },
    raw: { player, battleLog }
  };
}

function recentRoyaleItems(battleLog: any) {
  const items = Array.isArray(battleLog) ? battleLog : [];
  return items.slice(0, 5).map((battle: any) => {
    const team = battle.team?.[0] || {};
    const opponent = battle.opponent?.[0] || {};
    const crowns = number(team.crowns);
    const enemyCrowns = number(opponent.crowns);
    const result = crowns > enemyCrowns ? "win" : crowns < enemyCrowns ? "loss" : "draw";
    return {
      title: battle.type || battle.gameMode?.name || "Battle",
      subtitle: opponent.name ? `vs ${opponent.name}` : battle.battleTime,
      result,
      value: `${crowns}-${enemyCrowns}`
    };
  });
}

async function fetchClashRoyale(env: Env, profile: Profile): Promise<{ summary: Summary; raw: unknown }> {
  const player = await fetchSupercell(`/players/${encodeTag(profile.player_tag)}`, env.CLASH_ROYALE_API_TOKEN, env.CLASH_ROYALE_API_BASE, "https://api.clashroyale.com/v1");
  let battleLog: any = [];
  try {
    battleLog = await fetchSupercell(`/players/${encodeTag(profile.player_tag)}/battlelog`, env.CLASH_ROYALE_API_TOKEN, env.CLASH_ROYALE_API_BASE, "https://api.clashroyale.com/v1");
  } catch (error) {
    battleLog = { warning: normalizeError(error) };
  }

  const wins = number(player.wins);
  const losses = number(player.losses);
  const deck = Array.isArray(player.currentDeck) ? player.currentDeck : [];

  return {
    summary: {
      game: "clash_royale",
      title: player.name || profile.display_name,
      subtitle: `${player.tag || profile.player_tag} · Arena ${player.arena?.name || "—"}`,
      primaryMetric: { label: "Trophies", value: number(player.trophies) },
      metrics: [
        { label: "Best trophies", value: number(player.bestTrophies) },
        { label: "Wins", value: wins },
        { label: "Losses", value: losses },
        { label: "Win rate", value: percent(wins, wins + losses), help: "Career" },
        { label: "Battle count", value: number(player.battleCount) },
        { label: "3-crown wins", value: number(player.threeCrownWins) },
        { label: "Cards found", value: number(player.cards?.length) },
        { label: "Level", value: number(player.expLevel) }
      ],
      recent: recentRoyaleItems(battleLog),
      highlights: [
        player.clan?.name ? `Clan: ${player.clan.name}` : "No clan shown",
        deck.length ? `Current deck: ${deck.slice(0, 4).map((card: any) => card.name).join(", ")}${deck.length > 4 ? "..." : ""}` : "No current deck returned",
        player.leagueStatistics?.currentSeason?.bestTrophies ? `Season best: ${player.leagueStatistics.currentSeason.bestTrophies}` : "Season best not available"
      ],
      updatedAt: new Date().toISOString()
    },
    raw: { player, battleLog }
  };
}

async function fetchClashOfClans(env: Env, profile: Profile): Promise<{ summary: Summary; raw: unknown }> {
  const player = await fetchSupercell(`/players/${encodeTag(profile.player_tag)}`, env.CLASH_OF_CLANS_API_TOKEN, env.CLASH_OF_CLANS_API_BASE, "https://api.clashofclans.com/v1");
  const heroes = Array.isArray(player.heroes) ? player.heroes : [];
  const troops = Array.isArray(player.troops) ? player.troops : [];
  const spells = Array.isArray(player.spells) ? player.spells : [];
  const achievements = Array.isArray(player.achievements) ? player.achievements : [];
  const topAchievements = achievements
    .slice()
    .sort((a: any, b: any) => percent(number(b.value), number(b.target)) - percent(number(a.value), number(a.target)))
    .slice(0, 5);

  return {
    summary: {
      game: "clash_of_clans",
      title: player.name || profile.display_name,
      subtitle: `${player.tag || profile.player_tag} · Town Hall ${player.townHallLevel || "—"}`,
      primaryMetric: { label: "Trophies", value: number(player.trophies) },
      metrics: [
        { label: "Best trophies", value: number(player.bestTrophies) },
        { label: "War stars", value: number(player.warStars) },
        { label: "Attack wins", value: number(player.attackWins) },
        { label: "Defense wins", value: number(player.defenseWins) },
        { label: "Builder trophies", value: number(player.builderBaseTrophies || player.versusTrophies) },
        { label: "Donations", value: number(player.donations) },
        { label: "Heroes", value: heroes.length },
        { label: "Troops", value: troops.length }
      ],
      recent: topAchievements.map((item: any) => ({
        title: item.name || "Achievement",
        subtitle: item.info || "Progress",
        result: number(item.value) >= number(item.target) ? "success" : "neutral",
        value: `${number(item.value)}/${number(item.target)}`
      })),
      highlights: [
        player.clan?.name ? `Clan: ${player.clan.name}` : "No clan shown",
        player.league?.name ? `League: ${player.league.name}` : "League not available",
        `Town Hall: ${player.townHallLevel || "—"}`,
        `Builder Hall: ${player.builderHallLevel || "—"}`,
        `Spells unlocked: ${spells.length}`
      ],
      updatedAt: new Date().toISOString()
    },
    raw: { player }
  };
}

async function fetchPubg(env: Env, profile: Profile): Promise<{ summary: Summary; raw: unknown }> {
  if (!env.PUBG_API_KEY) throw new Error("Missing PUBG_API_KEY. Add it in Cloudflare secrets.");
  const base = (env.PUBG_API_BASE || "https://api.pubg.com").replace(/\/$/, "");
  const shard = profile.platform || env.PUBG_PLATFORM || "steam";
  const playerName = encodeURIComponent(profile.player_tag);
  const headers = {
    authorization: `Bearer ${env.PUBG_API_KEY}`,
    accept: "application/vnd.api+json"
  };
  const players = await fetchJson(`${base}/shards/${shard}/players?filter[playerNames]=${playerName}`, headers);
  const player = players?.data?.[0];
  if (!player?.id) throw new Error(`PUBG player not found on shard "${shard}".`);

  let lifetime: any = null;
  try {
    lifetime = await fetchJson(`${base}/shards/${shard}/players/${player.id}/seasons/lifetime`, headers);
  } catch (error) {
    lifetime = { warning: normalizeError(error) };
  }

  const modes = lifetime?.data?.attributes?.gameModeStats || {};
  const totals = Object.values(modes).reduce((acc: any, mode: any) => {
    acc.kills += number((mode as any).kills);
    acc.wins += number((mode as any).wins);
    acc.top10s += number((mode as any).top10s);
    acc.rounds += number((mode as any).roundsPlayed);
    acc.damage += number((mode as any).damageDealt);
    acc.assists += number((mode as any).assists);
    acc.headshots += number((mode as any).headshotKills);
    return acc;
  }, { kills: 0, wins: 0, top10s: 0, rounds: 0, damage: 0, assists: 0, headshots: 0 });

  const recentMatches = Array.isArray(player.relationships?.matches?.data)
    ? player.relationships.matches.data.slice(0, 5)
    : [];

  return {
    summary: {
      game: "pubg",
      title: player.attributes?.name || profile.display_name,
      subtitle: `${shard} · ${player.id}`,
      primaryMetric: { label: "Kills", value: totals.kills },
      metrics: [
        { label: "Wins", value: totals.wins },
        { label: "Top 10", value: totals.top10s },
        { label: "Rounds", value: totals.rounds },
        { label: "K/D", value: totals.rounds ? Math.round((totals.kills / Math.max(totals.rounds - totals.wins, 1)) * 100) / 100 : 0 },
        { label: "Damage", value: Math.round(totals.damage) },
        { label: "Assists", value: totals.assists },
        { label: "Headshots", value: totals.headshots },
        { label: "Win rate", value: percent(totals.wins, totals.rounds) }
      ],
      recent: recentMatches.map((match: any) => ({
        title: "Match",
        subtitle: match.id,
        result: "neutral",
        value: "ID"
      })),
      highlights: [
        `Platform shard: ${shard}`,
        `Account ID: ${player.id}`,
        lifetime?.warning ? `Lifetime stats warning: ${lifetime.warning}` : "Lifetime stats loaded"
      ],
      updatedAt: new Date().toISOString()
    },
    raw: { players, lifetime }
  };
}

async function fetchGameStats(env: Env, profile: Profile) {
  if (profile.game === "brawl_stars") return fetchBrawlStars(env, profile);
  if (profile.game === "clash_royale") return fetchClashRoyale(env, profile);
  if (profile.game === "clash_of_clans") return fetchClashOfClans(env, profile);
  if (profile.game === "pubg") return fetchPubg(env, profile);
  throw new Error("Unsupported game.");
}

function errorSummary(profile: Profile, error: unknown): Summary {
  return {
    game: profile.game,
    title: profile.display_name,
    subtitle: `${profile.player_tag} · Refresh failed`,
    primaryMetric: { label: "Status", value: 0 },
    metrics: [],
    recent: [],
    highlights: [normalizeError(error)],
    updatedAt: new Date().toISOString()
  };
}

async function saveSnapshot(db: Client, profile: Profile, status: string, summary: Summary, raw: unknown, error?: unknown, source = "api") {
  const id = crypto.randomUUID();
  await db.execute({
    sql: `INSERT INTO snapshots (id, profile_id, game, source, status, summary_json, raw_json, error)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    args: [
      id,
      profile.id,
      profile.game,
      source,
      status,
      JSON.stringify(summary),
      raw === undefined ? null : JSON.stringify(raw),
      error ? normalizeError(error) : null
    ]
  });
  return id;
}

async function refreshProfile(db: Client, env: Env, profile: Profile) {
  try {
    const { summary, raw } = await fetchGameStats(env, profile);
    const snapshotId = await saveSnapshot(db, profile, "success", summary, raw);
    await logActivity(db, "refresh_success", { profileId: profile.id, game: profile.game });
    return { status: "success", snapshotId, summary };
  } catch (error) {
    const summary = errorSummary(profile, error);
    const snapshotId = await saveSnapshot(db, profile, "error", summary, null, error);
    await logActivity(db, "refresh_error", { profileId: profile.id, game: profile.game, error: normalizeError(error) });
    return { status: "error", snapshotId, error: normalizeError(error), summary };
  }
}

async function handleDashboard(db: Client) {
  const [settings, profiles] = await Promise.all([getSettings(db), getProfiles(db, true)]);
  const snapshotMap = await getSnapshots(db, profiles);
  const publicProfiles = profiles.map((profile) => buildPublicProfile(profile, snapshotMap.get(profile.id) || []));
  return json({ settings, profiles: publicProfiles }, {
    headers: {
      "cache-control": "public, max-age=30, stale-while-revalidate=300"
    }
  });
}

async function handleAdminProfiles(request: Request, db: Client) {
  if (request.method === "GET") {
    const profiles = await getProfiles(db, false);
    return ok({ profiles });
  }

  if (request.method === "POST") {
    const body = await readJson(request);
    const input = normalizeProfileInput(body);
    const id = crypto.randomUUID();
    await db.execute({
      sql: `INSERT INTO profiles (id, game, display_name, player_tag, platform, region, avatar_url, is_featured, sort_order)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: [id, input.game, input.display_name, input.player_tag, input.platform, input.region, input.avatar_url, input.is_featured, input.sort_order]
    });
    await logActivity(db, "profile_created", { id, game: input.game });
    return ok({ message: "Profile added.", id });
  }

  return json({ error: "Method not allowed." }, { status: 405 });
}

async function handleAdminProfileById(request: Request, db: Client, id: string) {
  const existing = await getProfile(db, id);
  if (!existing) return json({ error: "Profile not found." }, { status: 404 });

  if (request.method === "PUT") {
    const body = await readJson(request);
    const input = normalizeProfileInput(body, existing);
    await db.execute({
      sql: `UPDATE profiles
            SET game = ?, display_name = ?, player_tag = ?, platform = ?, region = ?, avatar_url = ?, is_featured = ?, sort_order = ?, updated_at = datetime('now')
            WHERE id = ?`,
      args: [input.game, input.display_name, input.player_tag, input.platform, input.region, input.avatar_url, input.is_featured, input.sort_order, id]
    });
    await logActivity(db, "profile_updated", { id, game: input.game });
    return ok({ message: "Profile updated." });
  }

  if (request.method === "DELETE") {
    await db.execute({ sql: `DELETE FROM profiles WHERE id = ?`, args: [id] });
    await logActivity(db, "profile_deleted", { id });
    return ok({ message: "Profile deleted." });
  }

  return json({ error: "Method not allowed." }, { status: 405 });
}

async function handleSettings(request: Request, db: Client) {
  const body = await readJson(request);
  const allowed = ["site_title", "site_subtitle", "hero_badge", "profile_owner"];
  for (const key of allowed) {
    if (body[key] !== undefined) {
      await db.execute({
        sql: `INSERT INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))
              ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = datetime('now')`,
        args: [key, sanitizeText(body[key], key === "site_subtitle" ? 260 : 120)]
      });
    }
  }
  await logActivity(db, "settings_updated", allowed.reduce((acc: Record<string, unknown>, key) => {
    if (body[key] !== undefined) acc[key] = body[key];
    return acc;
  }, {}));
  return ok({ message: "Homepage settings saved." });
}

async function handleManualSnapshot(request: Request, db: Client, id: string) {
  const profile = await getProfile(db, id);
  if (!profile) return json({ error: "Profile not found." }, { status: 404 });
  const body = await readJson(request);
  const primaryValue = number(body.primaryValue);
  const summary: Summary = {
    game: profile.game,
    title: sanitizeText(body.title || profile.display_name, 90),
    subtitle: sanitizeText(body.subtitle || `${profile.player_tag} · Manual snapshot`, 180),
    primaryMetric: { label: sanitizeText(body.primaryLabel || "Manual stat", 50), value: primaryValue },
    metrics: Array.isArray(body.metrics) ? body.metrics.slice(0, 10) : [],
    recent: Array.isArray(body.recent) ? body.recent.slice(0, 8) : [],
    highlights: Array.isArray(body.highlights) ? body.highlights.slice(0, 8).map((item: unknown) => sanitizeText(item, 140)) : ["Manual snapshot saved"],
    updatedAt: new Date().toISOString()
  };
  const snapshotId = await saveSnapshot(db, profile, "manual", summary, body, undefined, "manual");
  await logActivity(db, "manual_snapshot", { profileId: id });
  return ok({ message: "Manual snapshot saved.", snapshotId });
}

export const onRequest: PagesFunction<Env> = async ({ request, env }) => {
  try {
    const db = getDb(env);
    await ensureSchema(db);

    const parts = parsePath(request);
    const [root, action, id] = parts;

    if (request.method === "GET" && root === "health") return ok({ message: "API is healthy." });
    if (request.method === "GET" && root === "dashboard") return handleDashboard(db);

    if (root !== "admin") {
      return json({ error: "Not found." }, { status: 404 });
    }

    const authError = assertAdmin(request, env);
    if (authError) return json({ error: authError }, { status: authError.startsWith("Unauthorized") ? 401 : 500 });

    if (request.method === "POST" && action === "init") {
      schemaReady = false;
      await ensureSchema(db);
      await logActivity(db, "database_initialized");
      return ok({ message: "Database initialized." });
    }

    if (action === "profiles" && !id) return handleAdminProfiles(request, db);
    if (action === "profiles" && id) return handleAdminProfileById(request, db, id);

    if (request.method === "POST" && action === "settings") return handleSettings(request, db);

    if (request.method === "POST" && action === "refresh" && id) {
      const profile = await getProfile(db, id);
      if (!profile) return json({ error: "Profile not found." }, { status: 404 });
      const result = await refreshProfile(db, env, profile);
      const status = result.status === "success" ? 200 : 502;
      return json(result, { status });
    }

    if (request.method === "POST" && action === "refresh-all") {
      const profiles = await getProfiles(db, false);
      const results = [];
      for (const profile of profiles) {
        const result = await refreshProfile(db, env, profile);
        results.push({ profileId: profile.id, game: profile.game, displayName: profile.display_name, ...result });
      }
      const failed = results.filter((item) => item.status === "error").length;
      return ok({ message: failed ? `Refresh finished with ${failed} error(s).` : "All profiles refreshed.", results });
    }

    if (request.method === "POST" && action === "manual-snapshot" && id) return handleManualSnapshot(request, db, id);

    return json({ error: "Not found." }, { status: 404 });
  } catch (error) {
    return json({ error: normalizeError(error) }, { status: 500 });
  }
};
