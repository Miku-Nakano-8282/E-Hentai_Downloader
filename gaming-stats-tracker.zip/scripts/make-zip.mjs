import { spawnSync } from "node:child_process";
import { existsSync, rmSync } from "node:fs";

const output = "gaming-stats-tracker.zip";
if (existsSync(output)) rmSync(output);
const result = spawnSync("zip", ["-r", output, ".", "-x", "node_modules/*", "dist/*", ".wrangler/*", ".dev.vars", ".env*"], {
  stdio: "inherit"
});
process.exit(result.status ?? 0);
